package com.example.workoutapp.utils

import android.content.Context
import android.media.MediaPlayer
import com.example.workoutapp.R

object SoundPlayer {
    private var mediaPlayer: MediaPlayer? = null

    fun playStartSound(context: Context) {
        playSound(context, R.raw.start_beep)
    }

    fun playPauseSound(context: Context) {
        playSound(context, R.raw.pause_beep)
    }

    private fun playSound(context: Context, resId: Int) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer.create(context, resId)
        mediaPlayer?.start()
    }
}
