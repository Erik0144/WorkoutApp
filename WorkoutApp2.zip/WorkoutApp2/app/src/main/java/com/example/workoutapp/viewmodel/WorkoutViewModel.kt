package com.example.workoutapp.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.os.CountDownTimer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.workoutapp.R
import com.example.workoutapp.data.Exercise

class WorkoutViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = application.getSharedPreferences("workout_prefs", Context.MODE_PRIVATE)

    private val exercises: List<Exercise> = listOf(
        Exercise("Jumping Jacks", "Springe mit Armen und Beinen auseinander und wieder zusammen.", R.drawable.jumping_jacks, 30),
        Exercise("Squats", "Geh in die Hocke und steh wieder auf.", R.drawable.squads, 30)
        // Weitere Übungen hier hinzufügen
    )

    private var currentIndex = 0
    private var isInPause = false
    private var timer: CountDownTimer? = null

    private val _currentExercise = MutableLiveData<Exercise?>()
    val currentExercise: LiveData<Exercise?> = _currentExercise

    private val _remainingTime = MutableLiveData<Int>()
    val remainingTime: LiveData<Int> = _remainingTime

    private val _isRunning = MutableLiveData<Boolean>()
    val isRunning: LiveData<Boolean> = _isRunning

    private val _statusText = MutableLiveData<String>()
    val statusText: LiveData<String> = _statusText

    private val _progress = MutableLiveData<Int>()
    val progress: LiveData<Int> = _progress

    fun loadProgress(): Int {
        return prefs.getInt("progress", 0)
    }

    fun saveProgress(progress: Int) {
        prefs.edit().putInt("progress", progress).apply()
    }

    fun startWorkout() {
        currentIndex = loadProgress()
        _progress.value = currentIndex
        startExercise()
    }

    private fun startExercise() {
        if (currentIndex >= exercises.size) {
            _currentExercise.value = null
            _statusText.value = "Workout abgeschlossen!"
            _isRunning.value = false
            saveProgress(0) // Fortschritt zurücksetzen
            return
        }

        val exercise = exercises[currentIndex]
        _currentExercise.value = exercise
        _statusText.value = "Übung: ${exercise.name}"
        _isRunning.value = true
        isInPause = false

        startTimer(exercise.durationSeconds) {
            startPause()
        }
    }

    private fun startPause() {
        _statusText.value = "Pause"
        isInPause = true
        _isRunning.value = true

        saveProgress(currentIndex + 1)

        startTimer(10) {  // 10 Sekunden Pause
            currentIndex++
            _progress.value = currentIndex
            startExercise()
        }
    }

    private fun startTimer(seconds: Int, onFinish: () -> Unit) {
        timer?.cancel()

        timer = object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                _remainingTime.value = (millisUntilFinished / 1000).toInt()
            }

            override fun onFinish() {
                _remainingTime.value = 0
                _isRunning.value = false
                onFinish()
            }
        }.start()
    }

    override fun onCleared() {
        super.onCleared()
        timer?.cancel()
    }
}
