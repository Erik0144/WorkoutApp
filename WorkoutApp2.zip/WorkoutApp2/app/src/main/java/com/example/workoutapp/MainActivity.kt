package com.example.workoutapp.ui

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.workoutapp.R
import com.example.workoutapp.utils.SoundPlayer
import com.example.workoutapp.viewmodel.WorkoutViewModel
import android.widget.*

class MainActivity : AppCompatActivity() {

    private val viewModel: WorkoutViewModel by viewModels {
        ViewModelProvider.AndroidViewModelFactory.getInstance(application)
    }

    private lateinit var tvStatus: TextView
    private lateinit var ivExercise: ImageView
    private lateinit var tvDescription: TextView
    private lateinit var tvTimer: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnStart: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        ivExercise = findViewById(R.id.ivExercise)
        tvDescription = findViewById(R.id.tvDescription)
        tvTimer = findViewById(R.id.tvTimer)
        progressBar = findViewById(R.id.progressBar)
        btnStart = findViewById(R.id.btnStart)

        btnStart.setOnClickListener {
            viewModel.startWorkout()
        }

        viewModel.currentExercise.observe(this) { exercise ->
            if (exercise != null) {
                tvStatus.text = exercise.name
                ivExercise.setImageResource(exercise.imageResId)
                tvDescription.text = exercise.description
                SoundPlayer.playStartSound(this)
            } else {
                tvStatus.text = "Workout abgeschlossen!"
                ivExercise.setImageResource(android.R.color.transparent)
                tvDescription.text = ""
            }
        }

        viewModel.remainingTime.observe(this) { time ->
            tvTimer.text = time.toString()
        }

        viewModel.progress.observe(this) { progress ->
            val total = 2 // Gesamtanzahl der Übungen (später dynamisch machen)
            progressBar.progress = (progress * 100) / total
        }

        viewModel.statusText.observe(this) { status ->
            tvStatus.text = status
            if (status == "Pause") {
                SoundPlayer.playPauseSound(this)
            }
        }
    }
}
